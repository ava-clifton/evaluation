from collections import defaultdict
import json

def problem_name(problem):
    end = problem.split("/")[-1]
    if "." in end:
        end, _ = end.split(".")
    return end

def parts_to_name_mixed(parts):
    end = ""
    if parts[0] == "IPC4":
        name = parts[2]
        if parts[3] == "ADL":
            end = "_ADL"
        if parts[2] == "NONTEMPORAL" or parts[2] == "STRIPS":
            name = parts[1]
        if name == "SMALL":
            name = "PSR-SMALL"
        return "2004_" + name + end

    if parts[0] == "IPC5":
        if parts[1] == "trucks" and parts[-1] != "Strips":
            end = "_ADL"
        return "2006_" + parts[1] + end

    if parts[0] == "AIPS-2000DataFiles":
        if parts[2] == "Elevator":
            end = "_simple"
        if parts[2] == "Schedule":
            end = "_ADL"
        return "2000_" + parts[2] + end

    if parts[0] == "IPC3":
        if parts[2] == "Satellite":
            return "2002_Satellite_ADL"
        else:
            return "2002_" + parts[2]

    if parts[0] == "AIPS98":
        if parts[1] == "assembly":
            return "1998_assembly_ADL"
        else:
            return "1998_" + parts[1]

    if parts[0] == "ipc2008":
        if parts[1] == "cybersec-strips":
            return "2008_cyber_security"
        else:
            return "2008_" + parts[1]

    if parts[0] == "ipc2011":
        return "2011_" + parts[2]

    print("can't handle:", parts)

def parts_to_name(parts):
    return parts_to_name_mixed(parts).upper()
    
name_to_count = defaultdict(lambda : 0)
with open("domains_problems") as f:
    for line in f.readlines():
        line = line.rstrip()
        domain, problem = line.split(" ")
        parts = domain.split("/")[1:-1]
        name_to_count[parts_to_name(parts)] += 1
        dname = parts_to_name(parts)
        pname = problem_name(problem)
        print(domain,problem,dname,pname)

with open("name_counts.json", "w") as outfile:
    json_object = json.dumps(name_to_count, indent=4)
    outfile.write(json_object)
